CITY OF CATASTROPHES 7.0 — C + C++

Files:
- engine.c   : C engine (random numbers, economy, building HP and disaster damage)
- engine.h   : C/C++ interface
- main.cpp   : game logic and interface in C++

Build on Windows (MinGW GCC/G++):
1. Open a terminal in this folder.
2. Run:
   gcc -std=c11 -Wall -Wextra -c engine.c -o engine.o
   g++ -std=c++17 -Wall -Wextra main.cpp engine.o -o CityOfCatastrophes.exe
3. Start the game:
   .\CityOfCatastrophes.exe

Important:
- Compile engine.c first with gcc.
- Then link main.cpp with g++.
- Do not compile engine.c with g++.
- On Windows, arrow-key tile selection uses _getch().
