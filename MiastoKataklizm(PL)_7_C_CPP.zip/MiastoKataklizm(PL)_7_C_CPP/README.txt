MIASTO KATAKLIZM 7.0 — C + C++

Pliki:
- engine.c   : silnik C (losowanie, ekonomia, HP i katastrofy)
- engine.h   : interfejs C/C++
- main.cpp   : gra i interfejs C++

Kompilacja w Windows (MinGW GCC/G++):
1. Otwórz terminal w tym folderze.
2. Wykonaj:
   gcc -std=c11 -Wall -Wextra -c engine.c -o engine.o
   g++ -std=c++17 -Wall -Wextra main.cpp engine.o -o MiastoKataklizm.exe
3. Uruchom:
   .\MiastoKataklizm.exe

Ważne:
- Najpierw kompiluj engine.c kompilatorem gcc.
- Następnie linkuj main.cpp kompilatorem g++.
- Nie kompiluj pliku engine.c przez g++.
- Na Windows strzałki w wyborze pola obsługuje _getch().
